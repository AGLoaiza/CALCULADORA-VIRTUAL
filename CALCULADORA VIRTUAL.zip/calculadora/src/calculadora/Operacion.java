package calculadora;

/**
 *
 * @author ALFONSO GUSTAVO LOAIZA SIBAJA
 */
public class Operacion {

    public static boolean esPrimo(int numero) {
        // El 0, 1 y 4 no son primos
        if (numero == 0 || numero == 1 || numero == 4) {
            return false;
        }
        for (int Resultado = 2; Resultado < numero / 2; Resultado++) {
            // Si es divisible por cualquiera de estos números, no
            // es primo
            if (numero % Resultado == 0) {
                return false;
            }
        }
        // Si no se pudo dividir por ninguno de los de arriba, sí es primo
        return true;
    }
    public static boolean isPalindrome(int Resultado) {
    if (Resultado < 0)
        return false;
    int div = 1;
    while (Resultado / div >= 10) {
        div *= 10;
    }
    while (Resultado != 0) {
        int l = Resultado / div;
        int r = Resultado % 10;
        if (l != r)
            return false;
        Resultado = (Resultado % div) / 10;
        div /= 100;
    }
    return true;
}
}
